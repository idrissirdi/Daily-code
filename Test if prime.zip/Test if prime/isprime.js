const form = document.getElementById('primebottle');
const result = document.getElementById('result');
form.addEventListener('submit', function(event) {
    event.preventDefault();
    const number = document.getElementById('i').value;
    const thingyinhtml = parseInt(number);
    let right ='';
    let isPrime = true;
    if (thingyinhtml <= 1) {
        isPrime = false;
    } else {
        for (let i = 2; i <= Math.sqrt(thingyinhtml); i++) {
            if (thingyinhtml % i === 0) {
                isPrime = false;
                break;
            }
        }
    }
    if (isPrime) {
        right=("prime");
    } else {
        right=("not prime");
    }
    const result = document.getElementById('result');
    result.textContent = thingyinhtml;
    result.textContent = right
 });